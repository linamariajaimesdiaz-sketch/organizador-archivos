# 📦 Organizador Inteligente de Archivos

Organiza automáticamente tu carpeta **Descargas** en carpetas personalizadas en tu **Escritorio**, con una interfaz web moderna que corre en tu propio computador.

![Python](https://img.shields.io/badge/Python-3.10%2B-blue?logo=python)
![Streamlit](https://img.shields.io/badge/Streamlit-1.35%2B-red?logo=streamlit)
![License](https://img.shields.io/badge/License-MIT-green)

---

## ✨ Características

- 🗂️ **Carpetas personalizadas** — tú defines los nombres (Facturas, Universidad, Fotos...)
- 🧠 **Clasificación inteligente** — analiza el nombre del archivo Y su contenido interno (.txt, .pdf, .docx)
- 👁️ **Vista previa con checkboxes** — elige qué archivos mover antes de confirmar
- ↩️ **Deshacer (Ctrl+Z)** — revierte la última organización con un clic
- 💾 **Memoria** — guarda tu configuración en `config.json` y la recuerda la próxima vez
- 🌐 **Acceso desde cualquier dispositivo** en tu red WiFi local

---

## 🖥️ Captura de pantalla

> La app corre en tu navegador en `http://localhost:8501`

---

## ⚙️ Requisitos

- Python 3.10 o superior
- pip

---

## 🚀 Instalación y uso

### 1. Clona el repositorio

```bash
git clone https://github.com/TU_USUARIO/organizador-archivos.git
cd organizador-archivos
```

### 2. Instala las dependencias

```bash
pip install -r requirements.txt
```

> **Opcional:** Para leer el contenido interno de PDFs y archivos Word:
> ```bash
> pip install pdfplumber python-docx
> ```
> Sin estas librerías la app funciona igual, solo clasifica por nombre del archivo.

### 3. Ejecuta la app

```bash
streamlit run app.py
```

La app abrirá automáticamente en tu navegador en `http://localhost:8501`.

Para acceder desde otro dispositivo en tu **misma red WiFi**, usa la URL de red que muestra la terminal (ej: `http://192.168.1.X:8501`).

---

## 📖 Cómo usarla

| Paso | Qué hacer |
|------|-----------|
| **01 · Mis Carpetas** | Escribe los nombres de tus carpetas y guarda la configuración |
| **02 · Vista Previa** | Haz clic en "🔍 Analizar" para ver cómo se clasificará cada archivo. Desmarca los que no quieres mover |
| **03 · Organizar** | Haz clic en "✨ Organizar Ahora" para mover los archivos seleccionados |
| **↩️ Deshacer** | Si te equivocas, el botón "Deshacer" devuelve todo a Descargas |

---

## 🗂️ Estructura del proyecto

```
organizador-archivos/
├── app.py              ← Código principal (UI + lógica)
├── requirements.txt    ← Dependencias
├── README.md           ← Este archivo
├── config.json         ← Se crea automáticamente al guardar carpetas
└── undo_log.json       ← Se crea automáticamente al organizar (para deshacer)
```

---

## 🧠 ¿Cómo clasifica los archivos?

Para cada archivo analiza **dos cosas**:

1. **El nombre del archivo** — busca palabras clave relacionadas con el nombre de cada carpeta
2. **El contenido interno** — si es `.txt`, `.pdf` o `.docx`, lee el texto dentro del archivo

**Ejemplo:** Si tienes una carpeta llamada `Facturas` y el archivo se llama `factura_enero.pdf` o contiene la palabra "factura" adentro → va a `Facturas/`.

Si no coincide con ninguna carpeta → va a `Otros/`.

---

## 💾 ¿Dónde se guardan los archivos de configuración?

| Archivo | Ubicación | Para qué sirve |
|---------|-----------|----------------|
| `config.json` | Junto al `app.py` | Guarda las carpetas que definiste |
| `undo_log.json` | Junto al `app.py` | Guarda el historial de la última organización para poder deshacerla |

---

## 🛠️ Dependencias

| Librería | Versión mínima | Para qué |
|----------|---------------|----------|
| `streamlit` | 1.35.0 | Interfaz web |
| `pandas` | 2.0.0 | Tabla de vista previa |
| `pdfplumber` | 0.11.0 | *(Opcional)* Leer PDFs |
| `python-docx` | 1.1.0 | *(Opcional)* Leer archivos Word |

---

## 📄 Licencia

MIT — úsalo, modifícalo y compártelo libremente.

